import React from "react";
import { View, Text } from "react-native";
import { estilos } from "./styleSheet/estilos";

function Cabecalho() {
  return (
    <View style={estilos.cabecalho}>
      <Text style={estilos.tituloCabecalho}>
        Linguagens de Programação
      </Text>

      <Text style={estilos.subtituloCabecalho}>
        Escolha sua tecnologia favorita
      </Text>
    </View>
  );
}

export default Cabecalho;