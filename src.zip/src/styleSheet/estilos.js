import {StyleSheet} from 'react-native';
export const estilos = StyleSheet.create({
    fundo: {
        flex: 1,
        backgroundColor: '#777373',
        alignItems: 'center',
        justifyContent: 'center',
    },
    conteudo: {
        width: '80%',
        backgroundColor: '#fff',
        padding: 70,
        borderRadius: 20,
        alignItems: 'center',
        
    },
    tituloConteudo: {
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    inputNome: { 
        width: '100%',
        height: 40,
        borderColor: '#ccc',
        borderWidth: 1,
        borderRadius: 5,
        paddingHorizontal: 10,
        marginBottom: 20,
    },
    textoConteudo: {
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    picker: {  
        width: '100%',
        height: 50,
        marginBottom: 20,
    },
    botao: {
        backgroundColor: '#007BFF',
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 5,
    },
    textoBotao: {
        color: '#fff',
        fontSize: 16,
    },
    textoResultado: {
        fontSize: 16,
        marginTop: 20,
        fontWeight: 'bold',
    },
    cabecalho: {
  width: "100%",
  backgroundColor: "#3c95b6",
  padding: 30,
  borderRadius: 20,
  borderBottomWidth: 2,
  marginBottom: '30%',

  alignItems: "center",
},

tituloCabecalho: {
  fontSize: 28,
  fontWeight: "bold",
  color: "#fff",
  
},

subtituloCabecalho: {
  fontSize: 16,
  color: "#fff",
  marginTop: 5,
  fontStyle: "italic",
},
}); 
