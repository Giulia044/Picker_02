import React from "react";
import { View, Text } from "react-native";
import Conteudo from "./src/Conteudo";
import Cabecalho from "./src/Cabecalho";
import { estilos } from "./src/styleSheet/estilos";

function App(){
  return(
    <View style={estilos.fundo}>
      <Cabecalho />
      <Conteudo />
    </View>
  );
}
export default App;

